create view VW_invalid_emails_by_month as
  select concat(date_format(`iznik`.`users_emails`.`added`, '%Y-%m-'), '01') AS `date`, count(0) AS `count`
  from (`iznik`.`users_emails_verify` join `iznik`.`users_emails` on ((`iznik`.`users_emails`.`id` =
                                                                       `iznik`.`users_emails_verify`.`emailid`)))
  where (`iznik`.`users_emails_verify`.`status` = 'invalid')
  group by `date`
  order by `date`;

