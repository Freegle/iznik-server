create view vw_multiemails as
  select `vw_manyemails`.`id`                                 AS `id`,
         `vw_manyemails`.`fullname`                           AS `fullname`,
         count(0)                                             AS `count`,
         group_concat(`vw_manyemails`.`email` separator ', ') AS `GROUP_CONCAT(email SEPARATOR ', ')`
  from `iznik`.`vw_manyemails`
  group by `vw_manyemails`.`id`
  order by `count` desc;

