create view vw_recentposts as
  select `iznik`.`messages`.`id`       AS `id`,
         `iznik`.`messages`.`date`     AS `date`,
         `iznik`.`messages`.`fromaddr` AS `fromaddr`,
         `iznik`.`messages`.`subject`  AS `subject`
  from (`iznik`.`messages` left join `iznik`.`messages_drafts` on ((`iznik`.`messages_drafts`.`msgid` =
                                                                    `iznik`.`messages`.`id`)))
  where ((`iznik`.`messages`.`source` = 'Platform') and isnull(`iznik`.`messages_drafts`.`msgid`))
  order by `iznik`.`messages`.`date` desc
  limit 20;

