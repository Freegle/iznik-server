create view VW_Essex_Searches as
  select cast(`iznik`.`users_searches`.`date` as date) AS `DATE`, count(0) AS `count`
  from (`iznik`.`users_searches` join `iznik`.`locations` on ((`iznik`.`users_searches`.`locationid` =
                                                               `iznik`.`locations`.`id`)))
  where (mbrwithin(`iznik`.`locations`.`geometry`, (select `iznik`.`authorities`.`polygon`
                                                    from `iznik`.`authorities`
                                                    where (`iznik`.`authorities`.`name` like '%essex%'))) and
         (`iznik`.`users_searches`.`date` > '2017-07-01'))
  group by cast(`iznik`.`users_searches`.`date` as date)
  order by `DATE`;

