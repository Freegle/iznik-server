create view vw_ECC as
  select `iznik`.`logs_src`.`date` AS `date`, count(0) AS `count`
  from `iznik`.`logs_src`
  where (`iznik`.`logs_src`.`src` = 'ECC')
  group by cast(`iznik`.`logs_src`.`date` as date)
  order by `iznik`.`logs_src`.`date`;

