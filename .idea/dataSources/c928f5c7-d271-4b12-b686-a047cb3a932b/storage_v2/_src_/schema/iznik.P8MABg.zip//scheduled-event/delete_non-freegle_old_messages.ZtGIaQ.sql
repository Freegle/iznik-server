create definer = root@localhost event `Delete Non-Freegle Old Messages`
  on schedule
    every '1' DAY
      starts '2016-01-02 04:00:00'
  on completion preserve
  disable on slave
  comment 'Non-Freegle groups don''t have old messages preserved.'
do
  SELECT * FROM messages INNER JOIN messages_groups ON messages.id = messages_groups.msgid INNER JOIN groups ON messages_groups.groupid = groups.id WHERE  DATEDIFF(NOW(), `date`) > 31 AND groups.type != 'Freegle';

