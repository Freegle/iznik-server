create view vw_recentgroupaccess as
  select `iznik`.`users_logins`.`lastaccess` AS `lastaccess`,
         `iznik`.`groups`.`nameshort`        AS `nameshort`,
         `iznik`.`groups`.`id`               AS `id`
  from ((`iznik`.`users_logins` join `iznik`.`memberships` on ((
    (`iznik`.`users_logins`.`userid` = `iznik`.`memberships`.`userid`) and
    (`iznik`.`memberships`.`role` in ('Owner', 'Moderator'))))) join `iznik`.`groups` on ((
    `iznik`.`memberships`.`groupid` = `iznik`.`groups`.`id`)))
  order by `iznik`.`users_logins`.`lastaccess` desc;

