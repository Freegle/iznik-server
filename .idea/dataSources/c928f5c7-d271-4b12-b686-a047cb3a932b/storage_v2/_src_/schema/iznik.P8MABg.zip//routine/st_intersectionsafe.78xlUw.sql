create function ST_IntersectionSafe(a geometry, b geometry)
  returns geometry
  BEGIN
  DECLARE ret GEOMETRY;
  DECLARE CONTINUE HANDLER FOR SQLSTATE '22023'
  BEGIN
	  SET ret = POINT(0.0000,90.0000);
  END;
 SELECT ST_Intersection(a, b) INTO ret;
  RETURN ret;
END;

