create view VW_SupportCallAverage as
  select avg(`t`.`total`) AS `AVG(total)`
  from (select `iznik`.`stats`.`date` AS `date`, sum(`iznik`.`stats`.`count`) AS `total`
        from `iznik`.`stats`
        where ((`iznik`.`stats`.`type` = 'SupportQueries') and
               ((to_days(now()) - to_days(`iznik`.`stats`.`date`)) <= 31))
        group by `iznik`.`stats`.`date`) `t`;

