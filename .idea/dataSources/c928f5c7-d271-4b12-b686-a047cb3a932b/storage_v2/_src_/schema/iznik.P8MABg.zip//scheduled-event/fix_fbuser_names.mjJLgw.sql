create definer = root@localhost event `Fix FBUser names`
  on schedule
    every '1' HOUR
      starts '2016-04-03 08:02:30'
  on completion preserve
  disable on slave
do
  UPDATE users SET fullname = yahooid WHERE yahooid IS NOT NULL AND fullname LIKE  'fbuser%';

