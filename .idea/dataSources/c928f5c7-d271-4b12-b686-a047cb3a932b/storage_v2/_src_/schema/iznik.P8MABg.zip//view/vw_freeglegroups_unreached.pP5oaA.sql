create view vw_freeglegroups_unreached as
  select `iznik`.`groups`.`id` AS `id`, `iznik`.`groups`.`nameshort` AS `nameshort`
  from `iznik`.`groups`
  where ((`iznik`.`groups`.`type` = 'Freegle') and (not((`iznik`.`groups`.`nameshort` like '%playground%'))) and
         (not((`iznik`.`groups`.`nameshort` like '%test%'))) and
         (not(`iznik`.`groups`.`id` in (select `iznik`.`alerts_tracking`.`groupid`
                                        from `iznik`.`alerts_tracking`
                                        where (`iznik`.`alerts_tracking`.`response` is not null)))))
  order by `iznik`.`groups`.`nameshort`;

