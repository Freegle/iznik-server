create function haversine(lat1 float, lon1 float, lat2 float, lon2 float)
  returns float
  comment 'Returns the distance in degrees on the Earth
             between two known points of latitude and longitude'
  BEGIN
    RETURN 69 * DEGREES(ACOS(
              COS(RADIANS(lat1)) *
              COS(RADIANS(lat2)) *
              COS(RADIANS(lon2) - RADIANS(lon1)) +
              SIN(RADIANS(lat1)) * SIN(RADIANS(lat2))
            ));
END;

