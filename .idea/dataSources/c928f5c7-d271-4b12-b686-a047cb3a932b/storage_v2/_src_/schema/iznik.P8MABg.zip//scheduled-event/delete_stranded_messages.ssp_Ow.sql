create definer = root@localhost event `Delete Stranded Messages`
  on schedule
    every '1' DAY
      starts '2015-12-23 04:30:00'
  on completion preserve
  disable on slave
do
  DELETE FROM messages WHERE id NOT IN (SELECT DISTINCT msgid FROM messages_groups);

