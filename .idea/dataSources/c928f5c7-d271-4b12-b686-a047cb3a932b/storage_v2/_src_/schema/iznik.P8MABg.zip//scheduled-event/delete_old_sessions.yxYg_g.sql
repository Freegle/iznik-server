create definer = root@localhost event `Delete Old Sessions`
  on schedule
    every '1' DAY
      starts '2016-01-29 04:00:00'
  on completion preserve
  disable on slave
do
  DELETE FROM sessions WHERE DATEDIFF(NOW(), `date`) > 31;

