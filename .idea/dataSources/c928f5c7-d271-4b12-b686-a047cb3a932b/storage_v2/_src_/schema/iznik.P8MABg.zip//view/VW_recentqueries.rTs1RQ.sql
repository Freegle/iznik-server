create view VW_recentqueries as
  select `iznik`.`chat_messages`.`id`             AS `id`,
         `iznik`.`chat_messages`.`chatid`         AS `chatid`,
         `iznik`.`chat_messages`.`userid`         AS `userid`,
         `iznik`.`chat_messages`.`type`           AS `type`,
         `iznik`.`chat_messages`.`reportreason`   AS `reportreason`,
         `iznik`.`chat_messages`.`refmsgid`       AS `refmsgid`,
         `iznik`.`chat_messages`.`refchatid`      AS `refchatid`,
         `iznik`.`chat_messages`.`date`           AS `date`,
         `iznik`.`chat_messages`.`message`        AS `message`,
         `iznik`.`chat_messages`.`platform`       AS `platform`,
         `iznik`.`chat_messages`.`seenbyall`      AS `seenbyall`,
         `iznik`.`chat_messages`.`reviewrequired` AS `reviewrequired`,
         `iznik`.`chat_messages`.`reviewedby`     AS `reviewedby`,
         `iznik`.`chat_messages`.`reviewrejected` AS `reviewrejected`,
         `iznik`.`chat_messages`.`spamscore`      AS `spamscore`
  from (`iznik`.`chat_messages` join `iznik`.`chat_rooms` on ((`iznik`.`chat_messages`.`chatid` =
                                                               `iznik`.`chat_rooms`.`id`)))
  where (`iznik`.`chat_rooms`.`chattype` = 'User2Mod')
  order by `iznik`.`chat_messages`.`date` desc;

