create function GetMaxDimensionT(g geometry)
  returns double
  BEGIN
DECLARE area, radius, diag DOUBLE;

SET area = AREA(g);
SET radius = SQRT(area / PI());
SET diag = SQRT(radius * radius * 2);
RETURN(diag);
END;

