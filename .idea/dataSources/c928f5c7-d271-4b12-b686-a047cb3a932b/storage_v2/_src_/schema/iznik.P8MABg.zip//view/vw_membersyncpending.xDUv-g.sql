create view vw_membersyncpending as
  select `iznik`.`memberships_yahoo_dump`.`id`            AS `id`,
         `iznik`.`memberships_yahoo_dump`.`groupid`       AS `groupid`,
         `iznik`.`memberships_yahoo_dump`.`members`       AS `members`,
         `iznik`.`memberships_yahoo_dump`.`lastupdated`   AS `lastupdated`,
         `iznik`.`memberships_yahoo_dump`.`lastprocessed` AS `lastprocessed`,
         `iznik`.`memberships_yahoo_dump`.`synctime`      AS `synctime`
  from `iznik`.`memberships_yahoo_dump`
  where (isnull(`iznik`.`memberships_yahoo_dump`.`lastprocessed`) or
         (`iznik`.`memberships_yahoo_dump`.`lastupdated` > `iznik`.`memberships_yahoo_dump`.`lastprocessed`));

