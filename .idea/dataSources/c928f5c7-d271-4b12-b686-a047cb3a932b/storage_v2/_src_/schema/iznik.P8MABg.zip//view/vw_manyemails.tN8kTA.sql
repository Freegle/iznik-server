create view vw_manyemails as
  select `iznik`.`users`.`id`           AS `id`,
         `iznik`.`users`.`fullname`     AS `fullname`,
         `iznik`.`users_emails`.`email` AS `email`
  from (`iznik`.`users` join `iznik`.`users_emails` on ((`iznik`.`users`.`id` = `iznik`.`users_emails`.`userid`)))
  where `iznik`.`users`.`id` in (select `iznik`.`users_emails`.`userid`
                                 from `iznik`.`users_emails`
                                 group by `iznik`.`users_emails`.`userid`
                                 having (count(0) > 4)
                                 order by count(0) desc);

