create view VW_routes as
  select `iznik`.`logs_events`.`route` AS `route`, count(0) AS `count`
  from `iznik`.`logs_events`
  group by `iznik`.`logs_events`.`route`
  order by `count` desc;

