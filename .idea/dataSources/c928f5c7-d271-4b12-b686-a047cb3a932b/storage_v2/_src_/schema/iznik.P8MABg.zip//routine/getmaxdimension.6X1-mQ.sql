create function GetMaxDimension(g geometry)
  returns double
  BEGIN
DECLARE area, radius, diag DOUBLE;

SET area = AREA(g);
SET radius = SQRT(area / PI());
SET diag = SQRT(radius * radius * 2);
RETURN(diag);

/* Previous implementation returns odd geometry exceptions 
DECLARE envelope POLYGON;
DECLARE sw, ne POINT; 
DECLARE xsize, ysize DOUBLE;

DECLARE EXIT HANDLER FOR 1416 
  RETURN(10000);

SET envelope = ExteriorRing(Envelope(g));
SET sw = PointN(envelope, 1);
SET ne = PointN(envelope, 3);
SET xsize = X(ne) - X(sw);
SET ysize = Y(ne) - Y(sw);
RETURN(GREATEST(xsize, ysize)); */
END;

