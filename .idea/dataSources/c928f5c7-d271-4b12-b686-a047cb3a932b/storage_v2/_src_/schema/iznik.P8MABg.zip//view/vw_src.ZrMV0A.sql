create view vw_src as
  select count(0) AS `count`, `iznik`.`logs_src`.`src` AS `src`
  from `iznik`.`logs_src`
  group by `iznik`.`logs_src`.`src`
  order by `count` desc;

