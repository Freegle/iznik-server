create definer = root@localhost event `Delete Old SQL Logs`
  on schedule
    every '1' DAY
      starts '2016-02-06 04:30:00'
  on completion preserve
  disable on slave
  comment 'Causes cluster hang - will replace with cron'
do
  DELETE FROM logs_sql WHERE DATEDIFF(NOW(), `date`) > 2;

