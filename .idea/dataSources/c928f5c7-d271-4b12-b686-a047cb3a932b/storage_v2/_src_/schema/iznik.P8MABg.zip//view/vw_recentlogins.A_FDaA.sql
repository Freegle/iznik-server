create view vw_recentlogins as
  select `iznik`.`logs`.`timestamp` AS `timestamp`,
         `iznik`.`users`.`id`       AS `id`,
         `iznik`.`users`.`fullname` AS `fullname`
  from (`iznik`.`users` join `iznik`.`logs` on ((`iznik`.`users`.`id` = `iznik`.`logs`.`byuser`)))
  where ((`iznik`.`logs`.`type` = 'User') and (`iznik`.`logs`.`subtype` = 'Login'))
  order by `iznik`.`logs`.`timestamp` desc;

