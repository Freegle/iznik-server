create definer = root@localhost event `Delete Unlicensed Groups`
  on schedule
    every '1' DAY
      starts '2015-12-23 04:00:00'
  on completion preserve
  disable on slave
do
  UPDATE groups SET publish = 0 WHERE licenserequired = 1 AND (licenseduntil IS NULL OR licenseduntil < NOW()) AND (trial IS NULL OR DATEDIFF(NOW(), trial) > 30);

