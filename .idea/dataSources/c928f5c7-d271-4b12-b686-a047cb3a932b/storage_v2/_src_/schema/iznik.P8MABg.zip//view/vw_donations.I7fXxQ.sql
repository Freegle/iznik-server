create view vw_donations as
  select sum(`iznik`.`users_donations`.`GrossAmount`)        AS `total`,
         cast(`iznik`.`users_donations`.`timestamp` as date) AS `date`
  from `iznik`.`users_donations`
  where (((to_days(now()) - to_days(`iznik`.`users_donations`.`timestamp`)) < 31) and
         (`iznik`.`users_donations`.`Payer` <> 'ppgfukpay@paypalgivingfund.org'))
  group by `date`
  order by `date` desc;

