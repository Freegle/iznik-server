create function GetCenterPoint(g geometry)
  returns point
  BEGIN
DECLARE envelope POLYGON;
DECLARE sw, ne POINT; 
DECLARE lat, lng DOUBLE;

SET envelope = ExteriorRing(Envelope(g));
SET sw = PointN(envelope, 1);
SET ne = PointN(envelope, 3);
SET lat = X(sw) + (X(ne)-X(sw))/2;
SET lng = Y(sw) + (Y(ne)-Y(sw))/2;
RETURN POINT(lat, lng);
END;

