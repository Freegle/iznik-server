create definer = root@localhost event `Update Member Counts`
  on schedule
    every '1' HOUR
      starts '2016-03-02 20:17:39'
  on completion preserve
  disable on slave
do
  update groups set membercount = (select count(*) from memberships where groupid = groups.id);

